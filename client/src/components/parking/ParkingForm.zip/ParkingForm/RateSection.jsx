// RateSection.js
import React from 'react';
import {
  Checkbox,
  FormControl,
  FormLabel,
  HStack,
  NumberInput,
  NumberInputField,
  VStack,
} from '@chakra-ui/react';

function RateSection({ parkingInfo, handleNumberInputChange }) {
  return (
    <VStack spacing={4}>
      {parkingInfo.bike && (
        <>
          <FormControl>
            <FormLabel>Bike Parking Rates</FormLabel>
            <HStack>
              {renderRateCheckbox('bikeHourly', 'Hourly')}
              {renderRateCheckbox('bikeMonthly', 'Monthly')}
            </HStack>
          </FormControl>
          {renderRateInputs('bike')}
        </>
      )}
      {parkingInfo.car && (
        <>
          <FormControl>
            <FormLabel>Car Parking Rates</FormLabel>
            <HStack>
              {renderRateCheckbox('carHourly', 'Hourly')}
              {renderRateCheckbox('carMonthly', 'Monthly')}
            </HStack>
          </FormControl>
          {renderRateInputs('car')}
        </>
      )}
    </VStack>
  );

  function renderRateCheckbox(name, label) {
    return (
      <Checkbox
        name={name}
        isChecked={parkingInfo[name]}
        onChange={(event) => {
          handleNumberInputChange(name, event.target.checked);
        }}>
        {label}
      </Checkbox>
    );
  }

  function renderRateInputs(vehicleType) {
    const hourly = `${vehicleType}Hourly`;
    const monthly = `${vehicleType}Monthly`;
    const hourlyRate = `${vehicleType}HourlyRate`;
    const monthlyRate = `${vehicleType}MonthlyRate`;

    return (
      <FormControl>
        <FormLabel>Rate Details</FormLabel>
        <HStack>
          {parkingInfo[hourly] && (
            <NumberInput
              min={0}
              value={parkingInfo[hourlyRate]}
              onChange={(value) => handleNumberInputChange(hourlyRate, value)}>
              <NumberInputField placeholder='Hourly Rate' />
            </NumberInput>
          )}
          {parkingInfo[monthly] && (
            <NumberInput
              min={0}
              value={parkingInfo[monthlyRate]}
              onChange={(value) => handleNumberInputChange(monthlyRate, value)}>
              <NumberInputField placeholder='Monthly Rate' />
            </NumberInput>
          )}
        </HStack>
      </FormControl>
    );
  }
}

export default RateSection;
