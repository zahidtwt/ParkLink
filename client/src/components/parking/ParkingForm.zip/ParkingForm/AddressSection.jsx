// AddressSection.js
import React from 'react';
import { FormControl, FormLabel, Input, VStack } from '@chakra-ui/react';

function AddressSection({ parkingInfo, handleInputChange }) {
  return (
    <VStack spacing={4}>
      <FormControl isRequired>
        <FormLabel>Address</FormLabel>
        <Input
          name='address'
          value={parkingInfo.address}
          onChange={handleInputChange}
          placeholder='Address'
        />
      </FormControl>
      <FormControl isRequired>
        <FormLabel>Area</FormLabel>
        <Input
          name='area'
          value={parkingInfo.area}
          onChange={handleInputChange}
          placeholder='Area'
        />
      </FormControl>
      <FormControl isRequired>
        <FormLabel>City</FormLabel>
        <Input
          name='city'
          value={parkingInfo.city}
          onChange={handleInputChange}
          placeholder='City'
        />
      </FormControl>
      <FormControl isRequired>
        <FormLabel>Post Code</FormLabel>
        <Input
          name='postCode'
          value={parkingInfo.postCode}
          onChange={handleInputChange}
          placeholder='Post Code'
        />
      </FormControl>
    </VStack>
  );
}

export default AddressSection;
