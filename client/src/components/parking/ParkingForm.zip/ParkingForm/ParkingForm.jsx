// ParkingForm.js
import React, { useState } from 'react';
import {
  Box,
  Button,
  Checkbox,
  Container,
  FormControl,
  FormLabel,
  Heading,
  Stack,
  Tag,
  TagLabel,
  TagLeftIcon,
  VStack,
} from '@chakra-ui/react';
import { FaAirbnb, FaUserShield } from 'react-icons/fa';
import AddressSection from './AddressSection';
import VehicleSection from './VehicleSection';
import RateSection from './RateSection';
import RulesSection from './RulesSection';

function ParkingForm() {
  const [parkingInfo, setParkingInfo] = useState({
    address: '',
    area: '',
    city: '',
    postCode: '',
    bikeHourly: false,
    bikeMonthly: false,
    carHourly: false,
    carMonthly: false,
    bikeHourlyRate: 0,
    bikeMonthlyRate: 0,
    carHourlyRate: 0,
    carMonthlyRate: 0,
    bike: false,
    car: false,
    bikeSlot: 0,
    carSlot: 0,
    cctv: false,
    guard: false,
    rules: [],
  });
  const handleCheckboxChange = (e, rule) => {
    if (rule) {
      if (e.target.checked) {
        setParkingInfo({ ...parkingInfo, rules: [...parkingInfo.rules, rule] });
      } else {
        setParkingInfo({
          ...parkingInfo,
          rules: parkingInfo.rules.filter((item) => item !== rule),
        });
      }
    } else {
      setParkingInfo({ ...parkingInfo, [e.target.name]: e.target.checked });
    }
  };

  const handleInputChange = (e) => {
    setParkingInfo({ ...parkingInfo, [e.target.name]: e.target.value });
  };

  const handleNumberInputChange = (name, value) => {
    setParkingInfo({ ...parkingInfo, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(parkingInfo);
  };

  return (
    <Container maxWidth='container.md'>
      <Box borderWidth={1} borderRadius='lg' p={6} mt={6} boxShadow='lg'>
        <Heading as='h2' size='lg' mb={4}>
          Add Parking Information
        </Heading>
        <form onSubmit={handleSubmit}>
          <VStack spacing={4} mb={'150px'}>
            <AddressSection
              parkingInfo={parkingInfo}
              handleInputChange={handleInputChange}
            />
            <VehicleSection
              parkingInfo={parkingInfo}
              handleCheckboxChange={handleCheckboxChange}
              handleNumberInputChange={handleNumberInputChange}
            />
            <RateSection
              parkingInfo={parkingInfo}
              handleInputChange={handleInputChange}
              handleNumberInputChange={handleNumberInputChange}
            />
            <RulesSection
              parkingInfo={parkingInfo}
              handleCheckboxChange={handleCheckboxChange}
            />

            <FormControl>
              <FormLabel>Extra Services</FormLabel>
              <Stack direction='row'>
                {renderTagCheckbox('cctv', 'CCTV', FaAirbnb)}
                {renderTagCheckbox('guard', 'Guard', FaUserShield)}
              </Stack>
            </FormControl>
            {/* Add any other form elements you need */}
            <Button type='submit' colorScheme='blue' mb={6}>
              Submit
            </Button>
          </VStack>
        </form>
      </Box>
    </Container>
  );

  function renderTagCheckbox(name, label, icon) {
    return (
      <Tag size='lg' variant='outline' borderRadius='full'>
        <Checkbox
          name={name}
          isChecked={parkingInfo[name]}
          onChange={handleCheckboxChange}
          iconColor='blue.500'
          iconSize='18px'>
          <TagLeftIcon boxSize='20px' as={icon} />
          <TagLabel>{label}</TagLabel>
        </Checkbox>
      </Tag>
    );
  }
}

export default ParkingForm;
